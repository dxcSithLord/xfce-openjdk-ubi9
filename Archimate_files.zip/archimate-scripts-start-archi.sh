#!/bin/bash
# ArchiMate Tool startup script for KASM environment
# Starts ArchiMate with proper Java configuration for KASM user

set -e

# Function to log messages with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ARCHI: $1"
}

log "Starting ArchiMate Tool for KASM user: $USER"

# Set ArchiMate environment variables
export ARCHI_HOME=${ARCHI_HOME:-/opt/archi/app}
export JAVA_HOME=${JAVA_HOME:-/usr/lib/jvm/java-21-openjdk}
export ARCHI_WORKSPACE=${ARCHI_WORKSPACE:-/home/kasmuser/ArchiMateWorkspace}

# Create workspace directory if it doesn't exist
mkdir -p "$ARCHI_WORKSPACE"

# Set Java options optimized for KASM environment
export _JAVA_OPTIONS="-Djava.awt.headless=false \
-Dfile.encoding=UTF-8 \
-Xms512m \
-Xmx2048m \
-XX:+UseG1GC \
-XX:MaxGCPauseMillis=200 \
-Dsun.java2d.xrender=true \
-Dawt.useSystemAAFontSettings=on \
-Dswing.aatext=true \
-Dswing.defaultlaf=com.sun.java.swing.plaf.gtk.GTKLookAndFeel"

# Ensure display is set
export DISPLAY=${DISPLAY:-:1}

# Wait for X server to be ready
log "Waiting for X server on display $DISPLAY..."
timeout=30
while [ $timeout -gt 0 ] && ! xdpyinfo -display $DISPLAY >/dev/null 2>&1; do
    sleep 1
    timeout=$((timeout - 1))
done

if [ $timeout -eq 0 ]; then
    log "ERROR: X server not available after 30 seconds"
    exit 1
fi

log "X server ready"

# Check if ArchiMate executable exists and is executable
if [ ! -x "$ARCHI_HOME/Archi" ]; then
    log "ERROR: ArchiMate executable not found or not executable at $ARCHI_HOME/Archi"
    exit 1
fi

# Verify workspace permissions for KASM user
if [ ! -w "$ARCHI_WORKSPACE" ]; then
    log "ERROR: Workspace $ARCHI_WORKSPACE is not writable for user $USER"
    exit 1
fi

log "Starting ArchiMate with workspace: $ARCHI_WORKSPACE"
log "Java Home: $JAVA_HOME"
log "ArchiMate Home: $ARCHI_HOME"

# Change to ArchiMate directory and start the application
cd "$ARCHI_HOME"

# Start ArchiMate with workspace parameter and KASM optimizations
exec "$ARCHI_HOME/Archi" \
    -data "$ARCHI_WORKSPACE" \
    -vmargs \
    -Dosgi.instance.area.default="$ARCHI_WORKSPACE" \
    -Duser.name="$USER" \
    -Duser.home="$HOME" \
    "$@"
