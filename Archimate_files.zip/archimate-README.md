# ArchiMate Tool for KASM Workspaces

## Overview

This Iron Bank compliant container provides the ArchiMate Tool (Archi) optimized for KASM Workspaces deployment. It includes enterprise architecture modeling capabilities with a secure, hardened GUI environment and dedicated KASM user configuration built on EPEL-based XFCE desktop.

## Container Hierarchy

```
ArchiMate KASM Container (this)
    ↓ inherits from
XFCE + OpenJDK 21 Container (with EPEL)
    ↓ inherits from  
OpenJDK 21 Container (Iron Bank)
    ↓ inherits from
UBI 9.6 (Iron Bank approved base)
```

## Features

- **ArchiMate Tool 5.4.0**: Complete enterprise architecture modeling
- **KASM User Configuration**: Dedicated kasmuser (UID 1001) for security
- **XFCE Desktop Environment**: Inherited EPEL-based lightweight desktop
- **OpenJDK 21 Runtime**: Inherited Java environment
- **Auto-launch ArchiMate**: Tool starts automatically for KASM experience
- **Optimized for KASM**: Panel, desktop, and workspace configuration
- **Iron Bank Security Compliance**: Full security hardening

## KASM User Configuration

### User Details
- **Username**: `kasmuser`
- **UID/GID**: `1001:1001` (Iron Bank compliant)
- **Home Directory**: `/home/kasmuser`
- **Shell**: `/bin/bash`
- **Workspace**: `/home/kasmuser/ArchiMateWorkspace`

### Security Features
- Non-root execution required by Iron Bank
- Numeric UID supports random UID assignment
- Minimal privileges and secure file permissions
- Workspace isolation for modeling projects

## Base Image Dependencies

- **Base**: `registry1.dso.mil/ironbank/opensource/xfce/xfce-openjdk21:4.18-openjdk21.0.5-ubi9.6`
- **Inherited Features**: EPEL-based XFCE desktop, OpenJDK 21, VNC server, security hardening
- **Added Features**: ArchiMate Tool, KASM user, optimized configuration

## KASM Workspace Integration

### Optimized Experience
- **Auto-launch**: ArchiMate Tool starts automatically when workspace loads
- **Desktop Integration**: Launcher in panel and desktop shortcut
- **Workspace Persistence**: ArchiMate workspace directory for model storage
- **User Experience**: Optimized layout for enterprise architecture modeling

### KASM Configuration Features
- Pre-configured XFCE panel with ArchiMate launcher
- Optimized desktop environment for modeling workflows
- Supervisor manages both desktop and ArchiMate processes
- VNC server optimized for KASM infrastructure
- EPEL-based packages for stable desktop experience

## File Organization

### KASM-Specific Configurations
Located in `kasm/` subdirectory for better organization:
- **kasm-xfce4-session.rc**: KASM-optimized XFCE session
- **kasm-panel.xml**: Panel configuration with ArchiMate launcher
- **kasm-supervisord.conf**: Supervisor configuration for auto-launch

### Application Configurations
Located in `config/` subdirectory:
- **archi.desktop**: Desktop shortcut for ArchiMate
- **archi-launcher.desktop**: Application menu launcher

## Kubernetes Deployment for KASM

### Basic KASM Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: archimate-kasm
  labels:
    app: archimate-kasm
spec:
  replicas: 1
  selector:
    matchLabels:
      app: archimate-kasm
  template:
    metadata:
      labels:
        app: archimate-kasm
    spec:
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001
        runAsGroup: 1001
        fsGroup: 1001
      containers:
      - name: archimate-kasm
        image: registry1.dso.mil/ironbank/opensource/archi/archimate-kasm:5.4.0-kasm-xfce4.18-ubi9.6
        ports:
        - containerPort: 5901
          name: vnc
          protocol: TCP
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: false
          runAsNonRoot: true
          runAsUser: 1001
          runAsGroup: 1001
          capabilities:
            drop:
            - ALL
        env:
        - name: VNC_RESOLUTION
          value: "1920x1080"
        - name: VNC_COL_DEPTH
          value: "24"
        volumeMounts:
        - name: tmp-volume
          mountPath: /tmp
        - name: workspace-volume
          mountPath: /home/kasmuser/ArchiMateWorkspace
      volumes:
      - name: tmp-volume
        emptyDir: {}
      - name: workspace-volume
        persistentVolumeClaim:
          claimName: archimate-workspace-pvc
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: archimate-workspace-pvc
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
```

### KASM Workspace Storage

| Mount Point | Purpose | Recommended Size | Persistence |
|-------------|---------|------------------|-------------|
| `/home/kasmuser/ArchiMateWorkspace` | ArchiMate models and projects | 10-20Gi | Required |
| `/home/kasmuser` | User configuration and cache | 2-5Gi | Optional |
| `/tmp` | Temporary files | 1Gi | Ephemeral |

## Resource Requirements for KASM

| Workload | CPU | Memory | Storage | Concurrent Users |
|----------|-----|---------|---------|------------------|
| **Light Modeling** | 500m | 1Gi | 5Gi | 10-15 |
| **Standard Modeling** | 1000m | 2Gi | 10Gi | 5-10 |
| **Heavy Modeling** | 2000m | 4Gi | 20Gi | 2-5 |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DISPLAY` | `:1` | X11 display number |
| `VNC_PORT` | `5901` | VNC server port for KASM |
| `VNC_RESOLUTION` | `1280x1024` | Screen resolution (recommend 1920x1080 for KASM) |
| `VNC_COL_DEPTH` | `24` | Color depth |
| `ARCHI_HOME` | `/opt/archi/app` | ArchiMate installation directory |
| `JAVA_HOME` | `/usr/lib/jvm/java-21-openjdk` | Java runtime directory |
| `ARCHI_WORKSPACE` | `/home/kasmuser/ArchiMateWorkspace` | ArchiMate workspace |
| `HOME` | `/home/kasmuser` | KASM user home directory |
| `USER` | `kasmuser` | KASM username |

## ArchiMate Tool Features

### Enterprise Architecture Modeling
- **TOGAF Support**: Complete TOGAF ADM implementation
- **ArchiMate 3.1**: Full ArchiMate language support
- **Multiple Views**: Business, Application, Technology layers
- **Model Analysis**: Impact analysis and relationships
- **Documentation**: Comprehensive model documentation

### KASM Optimizations
- **Auto-launch**: Tool starts automatically
- **Workspace Persistence**: Models saved in persistent storage
- **Performance Tuning**: Java GC optimization for GUI
- **Font Rendering**: Optimized for VNC display with EPEL fonts

## Troubleshooting for KASM

### Common KASM Issues

**ArchiMate Won't Auto-start**
- Check supervisor logs: `tail -f /tmp/archimate_autostart.log`
- Verify XFCE started properly: `tail -f /tmp/xfce4.log`
- Check ArchiMate logs: `tail -f /tmp/archimate.log`

**EPEL Package Issues**
- Verify EPEL repository: `rpm -q epel-release`
- Check package availability: `dnf repolist | grep epel`
- Validate XFCE components from EPEL

**Performance Issues in KASM**
- Increase memory allocation (minimum 1Gi)
- Optimize Java heap settings in startup script
- Monitor workspace storage I/O performance

### Log Files for KASM Debugging

- **Supervisor**: `/tmp/supervisord.log`
- **XFCE Desktop**: `/tmp/xfce4.log`
- **ArchiMate Tool**: `/tmp/archimate.log`
- **VNC Server**: `/tmp/x11vnc.log`

## License

This container includes components under various licenses:
- **ArchiMate Tool**: MIT License
- **XFCE**: GPL-2.0-or-later (inherited from EPEL)
- **OpenJDK**: GPL-2.0 with Classpath Exception (inherited)
- **Red Hat UBI**: Red Hat Universal Base Image EULA (inherited)

## References

- **ArchiMate Tool**: [Official Documentation](https://www.archimatetool.com/)
- **KASM Workspaces**: [KASM Documentation](https://kasmweb.com/)
- **Iron Bank**: [Repository Guidelines](https://repo1.dso.mil)
- **EPEL**: [Extra Packages for Enterprise Linux](https://fedoraproject.org/wiki/EPEL)
- **TOGAF**: [The Open Group Architecture Framework](https://www.opengroup.org/togaf)
