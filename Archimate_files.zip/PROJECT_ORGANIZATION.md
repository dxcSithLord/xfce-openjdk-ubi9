# Iron Bank Container Project - Proper Directory Organization

## Directory Structure Summary

The project has been reorganized according to Iron Bank repository standards with proper separation of concerns:

```
outputs/
├── xfce/                           # XFCE Container (separate entity)
│   ├── Dockerfile                  # Uses Iron Bank OpenJDK + EPEL
│   ├── hardening_manifest.yaml     # Includes EPEL resource
│   ├── testing_manifest.yaml       # EPEL validation tests
│   ├── README.md                   # EPEL repository documentation
│   ├── LICENSE                     # Component licenses
│   ├── config/                     # XFCE configurations
│   │   ├── xfce4-session.rc       # XFCE session config
│   │   └── vnc-startup.sh          # Enhanced VNC startup
│   └── scripts/                    # Container scripts
│       ├── docker-entrypoint.sh   # EPEL validation entrypoint
│       └── supervisord.conf       # Process management
│
└── archimate/                      # ArchiMate Container (separate entity)
    ├── Dockerfile                  # Uses XFCE base + KASM user
    ├── hardening_manifest.yaml     # ArchiMate resource
    ├── testing_manifest.yaml       # KASM user validation
    ├── README.md                   # KASM workspace documentation
    ├── LICENSE                     # All component licenses
    ├── config/                     # Application configurations
    │   ├── archi.desktop           # Desktop shortcut
    │   └── archi-launcher.desktop  # Application menu launcher
    ├── scripts/                    # ArchiMate scripts
    │   └── start-archi.sh          # KASM user startup script
    └── kasm/                       # KASM-specific configurations
        ├── kasm-xfce4-session.rc  # KASM optimized session
        ├── kasm-panel.xml          # Panel with ArchiMate launcher
        └── kasm-supervisord.conf   # Auto-launch configuration
```

## Key Improvements Made

### 1. **Proper Directory Separation**
- **xfce/** - XFCE container as separate entity (not subdirectory)
- **archimate/** - ArchiMate container as separate entity
- Each follows Iron Bank repository structure requirements

### 2. **EPEL Repository Implementation**
Following the uploaded EPELRepository.tid instructions:
- CodeReady Builder repository enabled
- EPEL release package as resource in hardening manifest
- Proper EPEL installation sequence in Dockerfile
- EPEL validation in testing manifest

### 3. **KASM Configuration Organization**
KASM-related files grouped in `kasm/` subdirectory:
- **kasm-xfce4-session.rc** - KASM optimized XFCE session
- **kasm-panel.xml** - Panel configuration with ArchiMate launcher
- **kasm-supervisord.conf** - Supervisor with auto-launch

### 4. **Enhanced EPEL Integration**
Based on the EPEL instructions provided:
```bash
# CodeReady Builder repository (handled in Dockerfile)
subscription-manager repos --enable codeready-builder-for-rhel-9-$(arch)-rpms

# EPEL installation (as resource in hardening manifest)
dnf install https://dl.fedoraproject.org/pub/epel/epel-release-latest-9.noarch.rpm

# XFCE installation from EPEL
dnf --enablerepo=epel groupinstall "Xfce"
```

### 5. **Container Hierarchy**
```
ArchiMate KASM Container
    ↓ inherits from
XFCE + OpenJDK 21 Container (with EPEL)
    ↓ inherits from  
OpenJDK 21 Container (Iron Bank existing)
    ↓ inherits from
UBI 9.6 (Iron Bank approved base)
```

## Iron Bank Submission Ready

### XFCE Container Features:
✅ **EPEL Repository**: Properly configured with resource validation  
✅ **Package Management**: XFCE packages from EPEL, core from UBI  
✅ **Security Hardening**: All Iron Bank compliance measures  
✅ **Proper Structure**: Iron Bank repository standard  

### ArchiMate Container Features:
✅ **KASM User**: kasmuser (UID 1001) for non-root execution  
✅ **KASM Configuration**: Grouped in kasm/ subdirectory  
✅ **Auto-launch**: ArchiMate starts automatically  
✅ **Workspace Persistence**: Dedicated modeling workspace  
✅ **Desktop Integration**: Panel launcher and desktop shortcuts  

## File Organization Benefits

### **Separation of Concerns**
- XFCE container: General GUI base for any Java application
- ArchiMate container: Specialized for KASM modeling workflows
- KASM configs: Grouped separately for maintainability

### **Maintainability**
- EPEL repository management centralized in XFCE base
- KASM optimizations grouped in dedicated subdirectory
- Clear inheritance hierarchy for updates and patches

### **Iron Bank Compliance**
- Each container in separate directory with full Iron Bank structure
- Proper resource declarations for EPEL and ArchiMate
- Complete testing and documentation for both containers

This organization follows Iron Bank best practices while providing clear separation between the base desktop capability and the specialized KASM modeling application.
